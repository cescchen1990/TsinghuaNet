# coding=utf-8
import requests
username = 'xxx' # 引号内输入你的用户名
password = 'xxx' # 引号内输入你的密码
def connect(): # 联网函数
    params = {'action': 'login', 'username':username, 'password': password, 'ac_id': 1}
    r = requests.post('http://net.tsinghua.edu.cn/do_login.php', params = params)
def testTUnet(): # 测试是否断网
    try:
        r = requests.get('http://baidu.com', timeout=1) # 用百度来测试网络连接状态
        r.raise_for_status()
        print('connected')
    except:
        connect() # 如果断网就联网

if __name__ == '__main__':
    testTUnet()