本程序采用的是https://github.com/Berrysoft/TsinghuaNet 的程序
仅为方便大家自动联网使用。

使用方法：
1. 运行首次运行修改账号密码
其中密码输入时看不见输入，输不对多试。
2.运行run.bat, 其中run.bat 可以用文本编辑器改登录时间。目前设置为1800s 即30分钟，半小时。


Sai Chen
Yuanmu Yang' s Group